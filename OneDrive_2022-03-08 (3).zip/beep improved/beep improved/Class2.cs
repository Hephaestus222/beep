﻿using System;
using System.Collections.Generic;
using System.Text;

namespace beep_improved
{
    class Class2
    {
    }
}
